﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockedMainProject
{
    public interface IDetails
    {
        string ShowCompany();
        string ShowStudent();
        String Greeting();
    }
}

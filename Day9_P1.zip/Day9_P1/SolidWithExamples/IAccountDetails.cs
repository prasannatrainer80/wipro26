﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidWithExamples
{
    internal interface IAccountDetails
    {
        void PfDetails();
        void PaySlips();

    }
}

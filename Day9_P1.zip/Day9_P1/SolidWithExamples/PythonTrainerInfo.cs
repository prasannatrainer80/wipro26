﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidWithExamples
{
    internal class PythonTrainerInfo : ITrainerData
    {
        public void City()
        {
            Console.WriteLine("City is Chennai...");
        }

        public void Email()
        {
            Console.WriteLine("Email is chandra@gmail.com");
        }

        public void Name()
        {
            Console.WriteLine("Name is Chandra Sekhar...");
        }
    }
}

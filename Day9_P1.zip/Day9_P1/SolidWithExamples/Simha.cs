﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidWithExamples
{
    internal class Simha : Training
    {
        public override void ShowInfo()
        {
            Console.WriteLine("Hi I am Vijaya Simha...");
        }
    }
}

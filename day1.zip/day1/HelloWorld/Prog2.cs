﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Prog2
    {
        static void Main()
        {
            string sname;
            Console.WriteLine("Enter Your Name   ");
            sname = Console.ReadLine();
            Console.WriteLine("Name is " +sname);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsExamples
{
    internal class Emp
    {
        public int Empno { get; set; }
        public string Name { get; set; }
        public int? LeaveDays { get; set; }

        public Nullable<int> Status { get; set; }

    }

}

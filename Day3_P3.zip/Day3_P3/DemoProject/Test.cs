﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{
    internal class Test
    {
        //int a, b;
        //a = 5;
        //b = 7;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOps
{
    internal class MainProg2
    {
        static void Main()
        {
            Demo demo = new Demo();
            demo.Name();
            demo.Email();
        }
    }
}

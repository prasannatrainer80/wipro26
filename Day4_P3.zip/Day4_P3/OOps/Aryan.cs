﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOps
{
    internal class Aryan : ITraining
    {
        public void Email()
        {
            Console.WriteLine("Email is aryan@gmail.com");
        }

        public void Name()
        {
            Console.WriteLine("Name is Aryan...");
        }
    }
}

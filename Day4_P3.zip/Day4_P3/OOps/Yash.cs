﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOps
{
    internal class Yash : ITraining
    {
        public void Email()
        {
            Console.WriteLine("Email is yash@gmail.com");
        }

        public void Name()
        {
            Console.WriteLine("Name is Yash...");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{

    internal class StaticTest
    {
        public static void Show()
        {
            Console.WriteLine("Wipro Dynamic Training...");
            Console.WriteLine("Timings from 8.45 to 5.45");
            Console.WriteLine("Trainer is Prasanna...");
        }

        static void Main()
        {
            Show();
        }
    }
}

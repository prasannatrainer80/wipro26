select * from LeaveDetails
GO

Insert into LeaveDetails(Empno,LeaveStartDate,LeaveEndDate,LeaveReason)
values(1,'01-12-2026','10-12-2026','Going Home'),
(2,'10-12-2026','12-12-2026','Exams'),
(3,'09-12-2026','10-12-2026','Visit Temples'),
(1,'10-12-2026','12-12-2026','Testing'),
(1,'01-11-2026','10-11-2026','Exams'),
(3,'01-12-2026','10-12-2026','Tour')
GO


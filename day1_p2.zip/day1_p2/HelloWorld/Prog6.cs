﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Prog6
    {
        static void Main()
        {
            int a = 12;
            double b = 12.5;
            string str = "Wipro";
            bool flag = true;
            Console.WriteLine("A value is  " +a);
            Console.WriteLine("B value is  " +b);
            Console.WriteLine("Str is  " +str);
            Console.WriteLine("Flag Value is  " +flag);
        }
    }
}

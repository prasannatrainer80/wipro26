﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Prog7
    {
        static void Main()
        {
            int x = 10;
            Console.WriteLine(++x);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{
    internal class Quiz4
    {
        static void Main()
        {
            int ch = 'A';
            Console.WriteLine(ch);
        }
    }
}

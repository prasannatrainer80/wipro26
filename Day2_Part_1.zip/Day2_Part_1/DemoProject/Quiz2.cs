﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{
    internal class Quiz2
    {
        static void Main()
        {
            string str = "sam";
            int a = 10, b = 20, c = 30;
            Console.WriteLine(str+a+b+c);
            Console.WriteLine(a+b+str+c);
            Console.WriteLine(a+b+c+str);
        }
    }
}

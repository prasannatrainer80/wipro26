﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{
    internal class Quiz5
    {
        static void Main()
        {
            char ch = 'A';
            ch++;
            Console.WriteLine(ch);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Prog1
    {
        static void Main()
        {
            string company = "Wipro";
            string trainer = "Prasanna";
            string mode = "Online";
            Console.WriteLine("Company  " +company);
            Console.WriteLine("Trainer "+trainer);
            Console.WriteLine("Mode  " +mode);
        }
    }
}

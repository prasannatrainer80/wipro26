﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Prog4
    {
        static void Main()
        {
            int age;
            Console.WriteLine("Enter Age   ");
            age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Age is  " +age);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileExamles
{
    internal class NegativeException : ApplicationException
    {
        public NegativeException(string error) : base(error) { }
    }
}

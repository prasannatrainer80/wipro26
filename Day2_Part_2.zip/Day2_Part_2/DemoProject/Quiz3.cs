﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProject
{
    internal class Quiz3
    {
        static void Main()
        {
            int i = 9;
            do
            {
                Console.WriteLine("Hello");
                i--;
            } while(i < 10);
        }
    }
}
